# Loading required libraries
library(readr) #loading library for reading files, CSV
library(utils) #loading library for unzipping and handling files

# ZIP file extraction directory
zip_file <- "Employee_Profile.zip" 
extract_folder <- "Employee_Profile" #creating a directory for storing extracted files

# Error handling: check ZIP file
if (!file.exists(zip_file)) {
  stop("ZIP file not found.")
} #displaying error message if zip file is not detected

# Create extraction folder if it does not exist
if (!dir.exists(extract_folder)) {
  dir.create(extract_folder)
} #creating a new folder if destination folder does not exist

# Unzip contents
unzip(zip_file, exdir = extract_folder) #extracting files from zip to designated or created folder

# Get list of CSV files inside the folder
csv_files <- list.files(extract_folder, pattern = "\\.csv$", full.names = TRUE) #displaying file location or path for each file with csv extention

# Error handling: check if CSV exists
if (length(csv_files) == 0) {
  stop("No CSV file found in the extracted folder.") #message if CSV file not found in extracted folder.
}

# Read the first CSV file found
employee_data <- read_csv(csv_files[1])

# Display the data
print(employee_data)