Employee Profile Processing
This project provides scripts to process employee data, export profiles, and read them back from a ZIP archive. It includes:

A Python script for creating employee dictionaries, retrieving details, and exporting profiles.
An R script for extracting ZIP files and reading employee data.

Step 1: Process and Export Employee Profile (Python)
Run the Python script to:

-Load total.csv
-Create a dictionary of employees
-Export a specific employee’s profile to CSV and ZIP

Step 2: Read Employee Profile (R)
Run the R script to:

-Extract Employee_Profile.zip
-Read the CSV file
-Display employee details

Error Handling

-Python script checks for missing columns and invalid employee names.
-R script checks for missing ZIP file and missing CSV files.