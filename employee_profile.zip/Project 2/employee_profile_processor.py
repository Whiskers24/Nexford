#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


df = pd.read_csv("total.csv", low_memory=False) #load dataset from folder, use low_memory=False to not detect inconsistencies in column data for now


# In[3]:


def create_employee_dictionary(dataframe): #Convert data frame rows into dictionary beginging with EMployee Name
    """
    Converts employee records into a dictionary
    Key   -> EmployeeName
    Value -> Employee details
    """
    try:
        employee_data = {} #create empty dictionary for results

        for _, row in dataframe.iterrows(): #use for loop to assign row elements to variable
            employee_data[row["EmployeeName"]] = {
                "JobTitle": row["JobTitle"],
                "BasePay": row["BasePay"],
                "OvertimePay": row["OvertimePay"],
                "OtherPay": row["OtherPay"],
                "Benefits": row["Benefits"],
                "TotalPay": row["TotalPay"],
                "TotalPayBenefits": row["TotalPayBenefits"],
                "Year": row["Year"]
            }

        return employee_data #store elements in employee_data

    except KeyError as e: #find and highlight exceptions in case of no data captured
        raise KeyError(f"Column missing in dataset: {e}")


# In[8]:


def get_employee_details(employee_name, employee_dict): #creates function to search for employee by name and provide details
    
    try:
        if not isinstance(employee_name, str): #use if conditions to prompt user to input string
            raise TypeError("Employee name must be a string")

        if employee_name not in employee_dict: #use if condition to check whether employee belongs to the dictionary, and prompt if not found.
            return "Employee not found"

        return employee_dict[employee_name] #show successful matches as record

    except Exception as e: #errors should be logged
        return f"Error: {e}"


# In[5]:


employee_dict = create_employee_dictionary(df) #build dictionary using data frame


# In[6]:


result = get_employee_details("NATHANIEL FORD", employee_dict)
print(result) #Pick an employee like Nathaniel Ford and print details from dictionary


# In[7]:


import zipfile

def export_employee_profile(employee_name, employee_dict): #extracting employee record to CSV
    try:
        details = get_employee_details(employee_name, employee_dict) #use exception handling to check for errors

        if details == "Employee not found": #Condition if found should store the details in CSV
            return details

        employee_df = pd.DataFrame([details])
        filename = f"{employee_name.replace(' ', '_')}_details.csv" #setting a file naming approach to apply
        employee_df.to_csv(filename, index=False) #ignore indexes for records

        with zipfile.ZipFile("Employee_Profile.zip", "w") as zipf:
            zipf.write(filename) # create zip file and store csv file in it

        return "Employee profile exported successfully" #provide remark if successfully executed

    except Exception as e: #where errors are detected log such errors
        return f"Export failed: {e}"


# In[ ]:





# In[ ]:




